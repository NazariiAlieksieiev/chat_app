export interface MessageType {
  id: number,
  author: string,
  text: string,
  createdAt: Date,
  chatId: number,
}
