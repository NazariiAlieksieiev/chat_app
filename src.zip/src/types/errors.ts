export enum Errors {
  Empty = 'Enter your Name',
  Download = "Упс, не має зв'язку",
}
