export interface Chat {
  id: number,
  name: string,
  chatAuthor: string,
}
