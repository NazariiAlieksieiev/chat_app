import { useEffect } from 'react';
import './WebSocketDownloader.scss';
import { useAppDispatch } from '../../state/app/hooks';
import { addMessage } from '../../state/features/messages';

const API_URL = process.env.REACT_APP_API_URL || '';
const socket = new WebSocket(API_URL);

export const WebSocketDownLoader: React.FC = () => {
  const dispatch = useAppDispatch();

  useEffect(() => {
    socket.addEventListener('message', (event) => {
      const message = JSON.parse(event.data);

      dispatch(addMessage(message));
    });

    return () => {
      socket.close();
    };
  }, []);

  return (
    <h1 className="title">
      Chat application
    </h1>
  );
};
